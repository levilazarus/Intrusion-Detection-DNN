# Dataset Instructions

This repository does **not** include the dataset to keep the repo lightweight and compliant.

You can use any public intrusion detection dataset (e.g., **UNR-IDD**, UNSW-NB15, CIC-IDS2017). 
Place download instructions or links here, for example:

- UNR-IDD (University of Nevada, Reno Intrusion Detection Dataset): add your source link here.
- UNSW-NB15: https://research.unsw.edu.au/projects/unsw-nb15-dataset

Once downloaded/preprocessed, place files under this `dataset/` folder, e.g.:
- `dataset/train.csv`
- `dataset/test.csv`
