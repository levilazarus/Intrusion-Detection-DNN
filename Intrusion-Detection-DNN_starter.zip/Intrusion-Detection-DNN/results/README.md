# Results

Place your evaluation artifacts here, e.g.:
- `confusion_matrix.png`
- `roc_curve.png`
- `classification_report.txt`
- `metrics.json`

> Tip: Keep this folder small and focused (PNG/TXT/JSON). Avoid checking in very large binary files.
